.. _basic-sample:

Basic Samples
#############

.. toctree::
   :maxdepth: 1
   :glob:

   **/*
